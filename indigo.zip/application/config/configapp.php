<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['backend_aplikasi'] = 'INSTRUMEN DIGITAL ONLINE';
$config['versi_aplikasi'] = 'Versi 1.0';
$config['frontend_aplikasi'] = 'Halaman Web';
$config['deskripsi_aplikasi'] = 'APA ITU APLIKASI INDIGO ?
                                Aplikasi INDIGO adalah aplikasi yang dapat  membantu Majelis Hakim dan Panitera Pengganti dalam melakukan pendistribusian instrumen panggilan kepada Jurusita secara lebih efektif dan efisien.';
$config['email_aplikasi'] = 'indigo@itpasim.com';
$config['link_aplikasi'] = 'localhost/indigo';