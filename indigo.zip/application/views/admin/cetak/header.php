<style type="text/css">
	.kop{
		width: 100%;
		text-align: center
	}
	.kop .kab{
		width: 65px
	}
	.kop .logo{
		width: 100px
	}
	.kop h1{
		margin: 0;
		padding: 0
	}
	.kop p{
		margin: 0;
		padding: 0;
		font-size: 12px;
	}
</style>
<h4 style="font-family: arial !important; text-decoration: underline;">KEJAKSAAN NEGERI</h4><br><br><br>
<table class="kop">
	<tr>
		<td width="80%">
			<h1>
				BERITA ACARA <br>
			</h1>
		</td>
	</tr>
</table>
<!-- <hr style="border:0;border-top:3px double #000"> -->