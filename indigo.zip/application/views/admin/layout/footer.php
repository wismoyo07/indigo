<div class="pull-right hidden-xs">
	<b><?= $versi_aplikasi; ?></b> 
</div>
<strong><?= developed(); ?> <?= copyright(); ?> </strong> 